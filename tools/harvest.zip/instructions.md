## Harvest Setup

1. Log in to harvestapp.com
2. Go to Settings → Developers → Personal Access Tokens
3. Click "Create new personal access token", give it a name, copy the token
4. Your Account ID is shown at the top of the same page
5. Paste both values into the fields above and click Save
