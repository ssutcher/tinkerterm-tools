---
name: harvest
description: >
  Guide for using the Harvest time tracking tool. Load when the user asks about
  logging time, viewing time entries, checking projects, or managing Harvest data.
  Also load when the user wants to set up or configure Harvest for the first time.
---

# Harvest Time Tracking

You have access to the Harvest time tracking API through the tool library.

## Setup

If Harvest isn't configured yet (execute_tool returns a settings error), walk the user through this:

**Required settings:**
- `harvestApiKey` — Your Harvest API key. Find it at: Harvest → Profile icon → Developers → Personal Access Tokens → Create new token
- `harvestAccountId` — Your numeric account ID. Found in the Harvest URL when logged in (e.g., `https://ACCOUNT_ID.harvestapp.com/`)

**Configure with:**
```
configure_tool({ tool: "harvest", setting: "harvestApiKey", value: "<your-key>" })
configure_tool({ tool: "harvest", setting: "harvestAccountId", value: "<your-id>" })
```

After saving, verify with `execute_tool({ tool: "harvest", action: "list_projects" })`.

The `harvestBaseUrl` setting has a working default and does not need to be configured.

## Common Workflows

### Check today's time
1. Use `list_time_entries` with `from` and `to` set to today's date
2. Summarize total hours and per-project breakdown

### Log time
1. If the user doesn't specify a project/task, use `list_project_assignments` first to find valid project_id and task_id combinations
2. Use `create_time_entry` with the correct IDs — this requires user confirmation
3. Never guess project or task IDs — always look them up first

### View projects
1. Use `list_projects` to see all active projects
2. Use `get_project` for details on a specific project

## Response Formatting

- Show time entries as a simple table: project, task, hours, notes
- Show totals per project and grand total
- For projects, show client name and budget status if available

## Important Rules

- Always confirm before logging time (create_time_entry has confirm: true)
- Harvest uses pagination — check if there are more pages in the response
- Dates are always YYYY-MM-DD format
- Task IDs come from project assignments, not from projects directly
