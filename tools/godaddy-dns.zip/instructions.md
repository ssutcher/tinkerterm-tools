## GoDaddy DNS Setup

This tool connects to the GoDaddy API to manage DNS records for your domains.

### Step 1: Create API Credentials

1. Go to [GoDaddy Developer Portal](https://developer.godaddy.com/keys)
2. Sign in with your GoDaddy account
3. Click **Create New API Key**
4. Fill in:
   - **Name:** A label for this key (e.g. "TinkerTerm")
   - **Environment:** Choose **Production** (not OTE/test)
5. Click **Next**
6. Copy both values:
   - **Key** → paste into the **API Key** field above
   - **Secret** → paste into the **API Secret** field above

> ⚠️ The Secret is only shown once. If you lose it, you'll need to create a new key.

### Step 2: Configure

Paste your Key and Secret into the fields in Settings → API Keys → GoDaddy DNS.

### Step 3: Verify

Ask Mocky: **"List my GoDaddy domains"** to confirm the credentials are working.

---

### Record Types

| Type | Used For | Data Format |
|------|----------|-------------|
| A | Point hostname to IPv4 | `1.2.3.4` |
| AAAA | Point hostname to IPv6 | `2001:db8::1` |
| CNAME | Alias to another hostname | `target.example.com` |
| MX | Mail server | `mail.example.com` (+ priority) |
| TXT | SPF, DKIM, domain verification | Text string |
| NS | Nameserver delegation | `ns1.example.com` |

### Notes

- Use `@` as the record name to target the root domain
- TTL minimum is 600 seconds (10 minutes); default is 3600 (1 hour)
- Deleting a record removes ALL records of that type+name combination
- Changes may take up to the TTL to propagate globally
