---
name: jira
description: >
  Guide for pushing and pulling issues from Jira. Use when the user asks to
  create Jira issues, check Jira status, sync tasks to/from Jira, search Jira,
  or transition issues. Triggers on "jira", "jira issue", "push to jira",
  "pull from jira", "jira board", "jira sprint", "create ticket".
---

# Jira

You have access to Jira through the tool library.

## Setup

If Jira isn't configured yet (execute_tool returns a settings error), walk the user through this:

**Required settings:**
- `jiraBaseUrl` — Full REST API base URL, e.g. `https://yourco.atlassian.net/rest/api/3`
- `jiraEmail` — Email address used to log in to Jira
- `jiraApiToken` — API token from id.atlassian.com/manage-profile/security/api-tokens

**Configure with:**
```
configure_tool({ tool: "jira", setting: "jiraBaseUrl", value: "https://yourco.atlassian.net/rest/api/3" })
configure_tool({ tool: "jira", setting: "jiraEmail", value: "you@example.com" })
configure_tool({ tool: "jira", setting: "jiraApiToken", value: "<your-token>" })
```

After saving, verify with `execute_tool({ tool: "jira", action: "get_projects" })`.

## Common Workflows

### Search for issues
```
execute_tool({ tool: "jira", action: "search_issues", input: { jql: "project = MYPROJ AND status = \"In Progress\"" } })
```
- Common JQL: `assignee = currentUser()`, `sprint in openSprints()`, `labels = "bug"`, `priority = High`
- Supports `maxResults` (default 50) and custom `fields`

### Get issue details
```
execute_tool({ tool: "jira", action: "get_issue", input: { issueKey: "PROJ-123" } })
```
Returns full details including description, comments, and linked issues.

### Create an issue
1. First, verify the project key with `get_projects`
2. Then create (requires confirmation):
```
execute_tool({ tool: "jira", action: "create_issue", input: {
  projectKey: "PROJ",
  summary: "Fix login timeout bug",
  issueType: "Bug",
  description: "Users are getting logged out after 5 minutes...",
  priority: "High"
}})
```
Issue types vary by project — common values: `Task`, `Bug`, `Story`, `Epic`, `Sub-task`.

### Transition an issue (change status)
1. First, get available transitions:
```
execute_tool({ tool: "jira", action: "get_transitions", input: { issueKey: "PROJ-123" } })
```
2. Then transition (requires confirmation):
```
execute_tool({ tool: "jira", action: "transition_issue", input: {
  issueKey: "PROJ-123",
  transition: { id: "21" }
}})
```
Always look up transition IDs — never guess them. They vary by project workflow.

### Add a comment
```
execute_tool({ tool: "jira", action: "add_comment", input: {
  issueKey: "PROJ-123",
  body: "Investigated this — root cause is the session timeout config in auth.ts."
}})
```

## Response Formatting

- Show issue lists as a table: key, summary, status, assignee, priority
- Link issue keys as `PROJ-123` (user can search for them)
- For transitions, show the current status → new status clearly
- When creating issues, confirm the project key and issue type with the user first

## Important Rules

- Always call `get_transitions` before `transition_issue` — IDs are project-specific
- Always call `get_projects` before `create_issue` if the project key is uncertain
- `create_issue` and `add_comment` and `transition_issue` require user confirmation (confirm: true)
- JQL strings use double quotes for values with spaces: `status = "In Progress"`
- The `fields` param in `search_issues` is comma-separated: `"summary,status,assignee"`
