## Jira Setup

1. In Jira, go to your profile → **Manage account** → **Security**
2. Under **API tokens**, click **Create and manage API tokens**
3. Click **Create API token**, give it a label (e.g. "TinkerTerm"), and copy the token
4. Enter your **Jira base URL** — the full REST API path, e.g.:
   `https://yourcompany.atlassian.net/rest/api/3`
5. Enter the **email address** you use to log in to Jira
6. Paste your **API token** into the token field and click Save

Once configured, ask the AI to search for issues, create tickets, or transition issues.
