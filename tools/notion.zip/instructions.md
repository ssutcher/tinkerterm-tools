## Notion Setup

1. Go to notion.so/my-integrations
2. Click "New integration", give it a name, and submit
3. Copy the "Internal Integration Token" shown on the next page
4. Paste it into the API Key field above and click Save
5. In Notion, open any page or database you want to access
6. Click the "..." menu → Connections → connect your integration
