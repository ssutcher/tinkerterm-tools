---
name: notion
description: >
  Notion workspace integration. Load when user asks about notes, docs,
  wikis, databases, or pages in Notion. Provides API patterns and tips.
---

# Notion Integration

You have access to the user's Notion workspace via the `notion` tool in the tool library.

## Available Actions

- **search** — Find pages and databases by keyword (POST /search)
- **get_page** — Get page metadata (title, properties, dates)
- **get_page_content** — Get the block content (body text, headings, lists) of a page
- **list_databases** — Find all databases the integration can access
- **query_database** — Get rows from a specific database with filters

## Key Concepts

- **Pages** have properties (title, dates, tags) and block content (paragraphs, headings)
- **Databases** are collections of pages with structured properties (like a spreadsheet)
- **Blocks** are content units inside pages (paragraph, heading, bulleted_list_item, etc.)
- **Page IDs** are UUIDs — the user can paste a Notion URL and you extract the ID from it

## Usage Patterns

**Finding content:**
1. Use `search` with a keyword to find relevant pages
2. Use `get_page` to see properties/metadata
3. Use `get_page_content` to read the actual body text

**Working with databases:**
1. Use `list_databases` or `search` with filter `{value: "database"}` to find databases
2. Use `query_database` with the database ID to get entries

## Tips

- The `list_databases` action internally uses the search endpoint with a database filter — it returns databases the integration has access to
- Notion page IDs in URLs look like: `notion.so/Page-Title-abc123def456` — the last 32 hex chars are the ID
- Block content is nested — a page's top-level blocks are fetched via `get_page_content`, but nested blocks need separate calls
- Pagination: if `has_more` is true in the response, use `start_cursor` from `next_cursor` to get the next page
