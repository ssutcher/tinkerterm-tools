## Asana Setup

1. Log in to [Asana](https://app.asana.com)
2. Click your **profile photo** (top-right corner)
3. Select **Settings**
4. Click the **Apps** tab in the sidebar
5. Scroll to **Developer apps** and click **Manage Developer Apps**
   — this opens the [Developer Console](https://app.asana.com/0/my-apps)
6. Under **Personal access tokens**, click **Create new token**
7. Give it a name (e.g. "TinkerTerm"), accept the API terms, and click **Create token**
8. Copy the token immediately — it's only shown once
9. Paste it into the field above and click Save

Once configured, ask the AI to list your workspaces, search tasks, or create new tasks.
