---
name: vercel
description: >
  Deploy and share content publicly via Vercel.
  Use when the user wants a shareable/public URL or mentions Vercel:
  "share this", "deploy to Vercel", "give me a share link", "get me a public URL",
  "put this on Vercel", "make this publicly accessible", "share the X bit",
  "share my GTM strategy", "share this with someone".
---

## What Vercel takes

Vercel serves **static files only** — HTML, CSS, JS, images, fonts. The directory you deploy must have an `index.html` at the root or visitors get a 404.

| Content type | What to do |
|---|---|
| HTML file / directory | Deploy directly with `deploy` action |
| Raw HTML string | Use `deploy_html` action — no file creation needed |
| Bit content (text/markdown) | Render to HTML first, then use `deploy_html` |
| Raw markdown | Must wrap in HTML — plain `.md` files are served as text |
| Images, PDFs | Must have an `index.html` that links to them |

## Sharing a bit

When the user asks to share a bit, document, or strategy:

**1. Read the bit**

Use `read_file` with the bit's full path (e.g. `~/.mocky/bits/1000079-2026-04-07--reimagine-gtm-strategy.txt`). If you don't know the path, use `search_bits` first.

**2. Render to HTML**

Build a clean, self-contained HTML page from the content. Include all styles inline — no external dependencies. Use a layout that fits the content type:
- Documents/strategies → readable article layout, dark header, sections
- Data/tables → structured layout with clear hierarchy
- Short notes → simple centered card

**3. Deploy with `deploy_html`**

Call `execute_tool`:
- tool: `"vercel"`
- action: `"deploy_html"`
- input: `{ "html": "<full html string>", "project_name": "optional-slug" }`

For `project_name`, derive a short slug from the content (e.g. `"reimagine-gtm"`, `"saul-bio"`). This controls the subdomain. If omitted, defaults to `tinkerterm-share`.

**4. Return the stable public URL — not the hash URL**

The tool response will include a URL. There are two URL formats Vercel produces:

| Format | What it is | Use it? |
|--------|-----------|---------|
| `project-name.vercel.app` | Stable production domain | ✅ YES |
| `project-abc123xyz-account.vercel.app` | Unique deployment URL | ❌ NO — behind auth |

**Always use the stable format.** If the tool returns a hash URL, derive the stable URL from the `project_name` you passed (or `tinkerterm-share` if you used the default). Example: `project_name: "reimagine-gtm"` → `https://reimagine-gtm.vercel.app`

Verify it's public before giving it to the user:
- If you get a 200 → give user `https://<project_name>.vercel.app`
- If you get 401/403 → tell user to go to Vercel Dashboard → project → Settings → Deployment Protection → set to "Only Preview Deployments"

Give the user the verified URL directly. No explanation needed.

## Deploying a directory

When the user already has files on disk:

**1. Confirm the directory has an `index.html`**

If not, ask which file should be the entry point, or offer to create one.

**2. Deploy with `deploy` action**

Call `execute_tool`:
- tool: `"vercel"`
- action: `"deploy"`
- input: `{ "directory": "/absolute/path/to/dir", "project_name": "optional" }`

## Checking the Vercel tool is configured

Before deploying, confirm the tool is configured. If `list_tools` shows Vercel with missing credentials, tell the user to add their token in Settings → Tools → Vercel.

## Handling errors

- `vercel_not_found` → Tell them to run `npm install -g vercel`
- `missing_token` → Settings → Tools → Vercel → add token
- `deploy_failed` → Show the output so they can see what went wrong
- `not_found` → Directory path is wrong; ask the user to confirm it

## Repeat deploys

Subsequent deploys to the same `project_name` update the same URL. No need to change the project name on reshares.

## Checking what's deployed

Use `execute_tool` with action `list_deployments` to see recent deploys, their status, and URLs.
