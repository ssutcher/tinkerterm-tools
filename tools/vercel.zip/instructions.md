## Vercel Setup

1. Go to vercel.com/account/tokens
2. Click "Create Token", give it a name (e.g. "TinkerTerm"), set scope to "Full Account"
3. Copy the token shown — you won't see it again
4. Paste it into the Vercel Token field above and click Save

The Vercel CLI must also be installed: `npm install -g vercel`

## Usage

Use `deploy` to push any directory of static files to a public URL.
Use `list_deployments` to see recent deploys and their status.

On first deploy to a new directory, Vercel creates a `.vercel` folder there — this links subsequent deploys to the same project (same URL).
