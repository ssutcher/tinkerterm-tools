## Playwright

No configuration required. Playwright uses the tests already in your project.

Use list_suites to see available test suites, then run_tests to execute one.
The screenshot action captures any URL to a PNG file.
