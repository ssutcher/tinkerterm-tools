---
name: pm-e2e
description: Run E2E browser tests against any live or dev web app from a plain English journey description. No codebase required. Auto-triggers when the user says "test my website", "test that users can", "run a test on [URL]", "check that [feature] works at [URL]", "e2e test this", "can you test [journey] on [URL]", "does signup work on", "verify that [user flow]", "test [competitor] app", "run the [name] journey", "run our testing tool on", "use the testing tool", "test this URL", "run e2e on", "test this site", "run a test on this", "let's test", "I want to test [URL]", "can we test [URL]". Works on any publicly accessible web URL.
---

# PM E2E Testing Skill

## Purpose

Enable PMs and non-developers to run automated browser tests against any live web app
by describing user journeys in plain English. Claude generates the Playwright test,
runs it in a real browser, and summarises the result.

No codebase access, no config, no test-writing knowledge required.

---

## How to Run a Journey Test (TinkerTerm)

Use the `playwright` tool's `run_journey` action. This generates and runs the test automatically.

**Required info:**
- `url` — the full URL (must include https://)
- `journey` — plain English description of what to test

**Example call:**
```
execute_tool("playwright", "run_journey", {
  "url": "https://www.boldium.com",
  "journey": "navigate to the work page and verify all case studies load"
})
```

The tool handles everything: writes the test, runs it in a real Chromium browser, and returns pass/fail results.

**Do NOT try to write test files or run bash commands.** Use `execute_tool` with `run_journey`.

---

## Step 1 — Gather Requirements

Extract from the user's message or ask conversationally:

| Required | What to ask |
|----------|-------------|
| **URL** | "What's the full URL of the app?" (must include https://) |
| **Journey** | "Walk me through what the user does — step by step." |

**Don't over-ask.** If the URL and journey are clear from the message, go straight to running.

**If the journey is vague** ("test signup"), ask one clarifying question:
> "What should the user see or land on after signing up? That helps me write the right assertion."

---

## Step 2 — Run the Test

Call `execute_tool("playwright", "run_journey", { url, journey })`.

The tool will:
1. Generate a Playwright test using AI
2. Run it in a visible Chromium browser
3. Return structured results

---

## Step 3 — Summarise Results

Interpret the tool output and present it in plain English:

**If `passed: true`:**
```
Journey passed in [X]s.

What was verified:
- [key thing 1 the test confirmed]
- [key thing 2]

The test ran in a real Chromium browser with screenshots and video captured.
```

**If `passed: false`:**
```
Journey failed at: "[failure_reason from result]"

What happened: [plain English explanation]

Likely cause: [your best assessment]

Want me to retry with a different approach, or is this a real issue with the site?
```

Do NOT show raw JSON or technical error messages. Translate them.

---

## Step 4 — Offer Next Steps

After every run:
```
Options:
- Test another user flow on this site
- Test a different URL
- [If failed] Retry with adjusted journey description
```

---

## Common Journey Descriptions That Work Well

- "navigate to the work/portfolio page and verify case studies load"
- "check that the contact form is visible and has required fields"
- "verify the main navigation links are all present"
- "go to the pricing page and check that pricing tiers are displayed"
- "verify that clicking the logo returns to the homepage"

---

## What This Is NOT For

- Tests against localhost (use the r2 e2e suite for that)
- Tests requiring login (unless you have credentials to provide)
- Load testing or performance benchmarks

This is for **quick, ad-hoc journey verification** against any live URL.
