---
name: fathom
description: >
  Use when the user asks about a past meeting, wants to find a transcript,
  or says things like "what did we discuss with X", "pull up the call with Y",
  "what was decided in the meeting about Z", or "get the transcript from last week's call".
---

# Fathom Meeting Intelligence

## Workflow

**Finding a meeting:**
1. Call `list_meetings` (no parameters) to get the most recent meetings
2. Look for the right meeting by title, date, or participants
3. If not on the first page, call `list_meetings` again with the `cursor` value from `next_cursor` to paginate

**Getting a transcript:**
1. Once you have the right meeting from `list_meetings`, note its `recording_id`
2. Call `get_transcript` with that `recording_id`
3. The transcript comes back as segments with speaker names and timestamps

## Tips

- Always call `list_meetings` first — you need the `recording_id` before you can get a transcript
- Meetings are returned newest-first by default
- If the user asks about a specific person or topic, scan the meeting titles from `list_meetings` before fetching transcripts — often the title alone answers the question
- Transcripts can be long. Summarize the key points unless the user specifically asks for the full text.
- When presenting transcript content, always attribute quotes to the correct speaker

## Common Patterns

**"What did we discuss with [company] last week?"**
→ `list_meetings` → find matching title → `get_transcript` → summarize key topics

**"What was decided about [topic] in our last call?"**
→ `list_meetings` → identify likely meeting → `get_transcript` → search for the decision

**"Get me the full transcript from the [title] meeting"**
→ `list_meetings` → find by title → `get_transcript` → present the full text
