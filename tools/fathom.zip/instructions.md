## Fathom Setup

1. Go to [app.fathom.video/profile/api](https://app.fathom.video/profile/api) (or navigate to **Profile → API** in the Fathom app)
2. Click **Create API Key**
3. Give it a name (e.g., "TinkerTerm")
4. Copy the generated key
5. Paste it into the **Fathom API key** field above

That's it — once configured, you can browse meetings and pull transcripts directly from TinkerTerm chat.
